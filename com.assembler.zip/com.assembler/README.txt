# simple assembler program
# use command
# java -jar assembler.jar
